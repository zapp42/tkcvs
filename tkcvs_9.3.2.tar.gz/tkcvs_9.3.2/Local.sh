# Do these steps (sh)
# Or just source this file

# To make the dev directory locally runnable
# from this directory (the one containing Local.txt)
TCLROOT=`pwd`
export TCLROOT
alias tkcvs=$TCLROOT/tkcvs/tkcvs.tcl
# Windows
#alias tkcvs="wish85 $TCLROOT/tkcvs/tkcvs.tcl"

